package day01_FirstProgramming;

public class GasReceipt {
    public static void main(String[] args) {
                  System.out.println("    MCLEAN STORE   ");
        System.out.println();
        System.out.println("2019-06-19  0.4:38PM ");;
        System.out.println("Gallons:     10.870");
        System.out.println("Price/gallon: $ 2.089");
        System.out.println("Fuel total:  $ 22.71");

    }










}
