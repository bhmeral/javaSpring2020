package day01_FirstProgramming;

public class HelloWorld {

    public static void  main(String[] args) {
        System.out.println("Hello World");

    }
/* Date: 03/25/2020
   My first Hello World project
   my struggles: muhtar is too slow

 */
}
