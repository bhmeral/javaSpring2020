package day01_FirstProgramming;

import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;

public class myName {
    public static void main(String[] args) {
        System.out.println(1);
        System.out.println(2);
        System.out.println(3);
    }




}
