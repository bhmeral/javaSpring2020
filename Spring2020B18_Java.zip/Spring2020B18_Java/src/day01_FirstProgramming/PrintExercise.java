package day01_FirstProgramming;

public class PrintExercise {
    public static void main(String[] args) {
        System.out.println("Tuncay");
        System.out.println("Oktay");
        System.out.println("Dovraon");
        System.out.println("Alison");

        System.out.println("hello");
        System.out.println("cybertek");
        System.out.println("mclean");
        System.out.println("batch 18");


    }




}
