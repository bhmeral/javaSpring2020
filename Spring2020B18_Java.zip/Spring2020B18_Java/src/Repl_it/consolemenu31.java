package Repl_it;

public class consolemenu31 {
    public static void main(String[] args) {

        System.out.println("bust");
        System.out.println("player loss");
        System.out.println("its a tie");
        System.out.println("player wins");







    }
}
