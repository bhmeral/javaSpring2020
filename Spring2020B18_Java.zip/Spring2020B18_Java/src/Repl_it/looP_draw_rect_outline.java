package Repl_it;

import java.util.Scanner;

public class looP_draw_rect_outline {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();

        for (int i=1; i<=3; i++){
            System.out.print("x");
        }
        System.out.println();
        for (int k=0; k<n; k++){
            System.out.println("x x");
        }
        for (int l=1; l<=3; l++){
            System.out.print("x");
        }




    }
}
