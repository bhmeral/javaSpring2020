package Repl_it;

public class for_loop_countdown {
    public static void main(String[] args) {
        for (int i =100; i>0; i-- ){
            System.out.println(i);
        }

    }
}
