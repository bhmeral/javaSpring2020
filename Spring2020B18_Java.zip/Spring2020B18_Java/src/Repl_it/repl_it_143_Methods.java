package Repl_it;

public class repl_it_143_Methods {

    public static void printHollowRect(){



        for (int k=1; k<=5; k++){
            System.out.print("*");

        }
        System.out.println();
        for (int l=0; l<=2; l++){
            System.out.println("*   *");
        }
        for (int y=1; y<=5; y++){
            System.out.print("*");

        }




    }


    public static void main(String[] args) {
        printHollowRect();
    }
}
