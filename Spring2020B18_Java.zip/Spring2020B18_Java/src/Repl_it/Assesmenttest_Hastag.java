package Repl_it;

public class Assesmenttest_Hastag {
    public static void main(String[] args) {
        for (int k=1;  k<=49; k++){
            System.out.println("#");
        }
    }
}
