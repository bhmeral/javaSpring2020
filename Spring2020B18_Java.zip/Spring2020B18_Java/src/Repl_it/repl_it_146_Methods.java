package Repl_it;

public class repl_it_146_Methods {
    public static void main(String[] args) {
        
    }
}
