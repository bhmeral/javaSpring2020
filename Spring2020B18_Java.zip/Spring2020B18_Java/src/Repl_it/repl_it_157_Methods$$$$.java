package Repl_it;

import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;

public class repl_it_157_Methods$$$$ {

    public static int max(int x, int y ){

        if (x>y){
            return y;
        }else{
            return x;
        }
    }

    public static void main(String[] args) {
       int result = max(1,2);
        System.out.println(result);
    }





}
