package Repl_it;

import java.util.Scanner;

public class replit23 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);


        int areaCode = input.nextInt();
        int localNumber = input.nextInt();

       String phonenumber = "(" +areaCode+ ")" +  "-" + localNumber;


        System.out.println("Calling number " + phonenumber);










    }
}
