package Repl_it;

public class repl_it_82_div3_For_Loop {
    public static void main(String[] args) {

        for (int i=1; i<=20 ; i++){
            if (i%3==0){
                System.out.println(i);
            }
        }

    }
}
