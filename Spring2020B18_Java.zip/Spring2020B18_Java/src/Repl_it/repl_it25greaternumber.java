package Repl_it;

public class repl_it25greaternumber {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        String greaternumber = " ";
        if(a>b){
            greaternumber =  a + " is greater than " + b ;
        }else{
            greaternumber = b +  " is greater than " + a ;
            System.out.println(greaternumber);

        }





    }


}
