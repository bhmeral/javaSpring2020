package Repl_it;

import java.util.Scanner;

public class repl_it_StringLength {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Enter your name");
        String name = scan.next();
        int length = name.length();
        System.out.println(length);





    }
}
