package Repl_it;

public class repl_it_112_Print_97_Asterisks {
    public static void main(String[] args) {

        for (int k = 1 ; k<=97; k++){
            System.out.println("*");
        }



    }
}
