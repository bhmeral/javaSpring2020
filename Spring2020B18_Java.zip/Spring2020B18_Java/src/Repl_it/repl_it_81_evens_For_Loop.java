package Repl_it;

public class repl_it_81_evens_For_Loop {
    public static void main(String[] args) {


        for (int i=2; i<=100; i++){
            if (i%2==0){
                System.out.println(i);
            }
        }

    }
}
