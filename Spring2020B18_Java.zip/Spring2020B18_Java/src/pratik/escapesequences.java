package pratik;

public class escapesequences {
    public static void main(String[] args) {

        /*
        \t: paragraph space
        \n: new line
        \": prints double quote to the console
        \':prints single quote to the console
        \\: prints \ to the console
         */

        System.out.println("Baha \nMERAL");
        System.out.println("\"Baha\" \"MERAL\"");
        System.out.println("\'Baha\'  \'MERAL\'");








































    }
}
