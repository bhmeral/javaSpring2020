package pratik;

public class primitivecasting {
}
