package pratik;

import java.util.Scanner;

public class ScannerAscendingNumbers {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);


        int num1 = input.nextInt();
        int num2 = input.nextInt();
        int num3 = input.nextInt();
        int num4 = input.nextInt();
        int num5 = input.nextInt();


        







    }
}
