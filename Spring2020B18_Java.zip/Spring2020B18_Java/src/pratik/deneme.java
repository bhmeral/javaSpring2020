package pratik;

public class deneme {
    public static void main(String[] args) {

    }
}
