package pratik;

public class practicevariable {
    public static void main(String[] args) {

       byte kg=100;
       double kginpoudnds= 2.24*kg;
        System.out.println( kg + " kg "+ " is equal to " +kginpoudnds+ " pounds");


        System.out.println("===========");


        byte liter=10;
        double literingallons= 3.3*liter;
        System.out.println( liter + " liter " + " is equal to " + literingallons+ " gallons");

        System.out.println("===========");

        byte pound=127;
        double poungdsinkg=pound/2.24;
        System.out.println( pound+ " pound " + " is equal to "+ poungdsinkg+ " kg ");

        System.out.println("======================" );

        byte gallons=127;
        double gallonsinliter=gallons/3.3;
        System.out.println( gallons+ " gallons " + " is equal to " + gallonsinliter+ " liter " );


























    }
}
