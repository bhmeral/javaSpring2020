package pratik;

public class variables {
    public static void main(String[] args) {

                 // smaller one can be assigned to larger one
       byte num1= 17;
       int  num2=num1;

                // larger one can not be assigned to smaller one
       int num3=345;
       //byte num4=num3;

        // finding volume of cube a*a*a

        byte a=5;
        int  volume=a*a*a;

        System.out.println(a);
        System.out.println(volume);


        int lira=1000;
        double liraindollar=lira/6.65;

        System.out.println(liraindollar);




        float pi=3.14f;
        byte  h=13;
        int   r=30;
        double volumeofcylinder= pi*r*r*h;

        System.out.println(volumeofcylinder);






















    }
}
