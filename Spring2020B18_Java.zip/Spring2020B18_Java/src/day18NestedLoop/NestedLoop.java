package day18NestedLoop;

public class NestedLoop {
    public static void main(String[] args) {

        for(int z=1; z<=5 ;z++){

            for (int i=1; i<=5 ;i++){
                System.out.println("Hello");
            }

        }


        for(int s=1; s<=5; s++){

            for (int z =1; z<=5; z++){
                System.out.print(z+ " ");
            }
            System.out.println();
        }


        System.out.println("=============================================");



      for (int i=0; i<7; i++){
          for (int a=1; a<7; a++ ){
              System.out.print("*");
          }
          System.out.println();
      }












    }
}
