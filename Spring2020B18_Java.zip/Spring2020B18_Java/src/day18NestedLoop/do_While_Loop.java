package day18NestedLoop;

public class do_While_Loop {
    public static void main(String[] args) {

        int i = 5;


        do {
            System.out.println("Hello World");
        }while (i == 0);






    }
}
