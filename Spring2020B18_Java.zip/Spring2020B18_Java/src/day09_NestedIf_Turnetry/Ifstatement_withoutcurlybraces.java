package day09_NestedIf_Turnetry;

public class Ifstatement_withoutcurlybraces {
    public static void main(String[] args) {
// you can if statement without curly braces if there is only one statement.
        if (0==0 && 3==3)

            System.out.println("Each number equal to each number");










    }
}
