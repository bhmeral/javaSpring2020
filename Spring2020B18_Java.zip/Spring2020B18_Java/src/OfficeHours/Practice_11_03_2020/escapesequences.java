package OfficeHours.Practice_11_03_2020;

public class escapesequences {
    public static void main(String[] args) {
        // it used for giving paragraph space
        System.out.println("\tJava is programmin language");
        // \n is used for starting a new line
        System.out.println("\nWe love learning Java");
        // \" used for printing ""
        System.out.println("We love learning \"Java\"");







    }
}
