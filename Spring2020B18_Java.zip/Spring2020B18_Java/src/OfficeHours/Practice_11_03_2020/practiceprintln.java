package OfficeHours.Practice_11_03_2020;

public class practiceprintln {
    public static void main(String[] args) {

        System.out.println("Cybertek School");
        System.out.println("My name is Baha");








    }
}
