package OfficeHours.Practice_11_03_2020;

public class variables {
    public static void main(String[] args) {
        /*
        brand
        year
        price
        model
        miles
         */


        String brand ="BMW";
        int year= 2020;
        float price= 1500000.50f;
        String model= "720D";
        int miles= 897;

        System.out.println("Brand: "+ brand);
        System.out.println("Year: "+ year);
        System.out.println("Price: "+ price);
        System.out.println("Model: "+ model);
        System.out.println("Miles: "+miles);

        System.out.println("00000000000000000000000000000000000000000000");
        System.out.println("Brand: "+ brand+ "\n" + "Year:" + year+ "\n" + "Price: "+ price+ "\n" +"Model: "+ model+ "\n" +"Miles: "+miles);

        System.out.println("00000000000000000000000");


        System.out.println("The vehicle is " + year +" "+ brand + " , " + "has "+ miles + " miles" + ", " + "price is " + price+ "USD");








    }
}
