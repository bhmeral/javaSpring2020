package OfficeHours.Practice_11_03_2020;

public class Practice_print {
    public static void main(String[] args) {

        System.out.print("Cybertek School");
        System.out.println("Cybertek School");
        System.out.println("Cybertek School");









    }
}
