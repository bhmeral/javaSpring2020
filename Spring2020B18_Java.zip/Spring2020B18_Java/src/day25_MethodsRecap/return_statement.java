package day25_MethodsRecap;

public class return_statement {
    public static void main(String[] args) {

        method1();
        System.out.println("Hello");
    }



    public static void method1(){
        if (10>9){
            return;
        }
        System.out.println("Hello Cybertek");
    }

}
