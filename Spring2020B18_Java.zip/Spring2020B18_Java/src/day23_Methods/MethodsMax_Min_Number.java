package day23_Methods;

public class MethodsMax_Min_Number {
    public static void main(String[] args) {

    }
}
