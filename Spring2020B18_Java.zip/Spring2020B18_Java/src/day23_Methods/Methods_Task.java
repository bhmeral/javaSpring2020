package day23_Methods;

import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;
import org.w3c.dom.ls.LSOutput;

public class Methods_Task {
    public static void main(String[] args) {
          /*


    step1: "Hello Cybertek"
    step2: "Hello World 5 times"
    step3: "Hello Batch18
    step4:  Hello World 5 times
    step5:  Hello Saim
    step6:  Hello World 5 times

         */

        System.out.println("Hello Cybertek");

        int i=0;
        while(i<5){
            System.out.println("Hello World 5 times");
            i++;
        }

        System.out.println("Hello Batch18");

        int k=0;
        while(k<5){
            System.out.println("Hello World 5 times");
            k++;
        }

        System.out.println("Hello Saim");


        int l=0;
        while(l<5){
            System.out.println("Hello World 5 times");
            l++;
        }
    }


}
