package day19_Array;

public class ArrayPractice2 {
    public static void main(String[] args) {

        int[] arr = {10,20,30};

        System.out.println(arr.length);

        double[] arr1 = new double[5];

        System.out.println(arr1[0]);
        System.out.println(arr1[1]);
        System.out.println(arr1[2]);
        System.out.println(arr1[3]);


        String[] Testers = new String[3]; // {"Reem", "Madina", "Osman};

        Testers[0] = "Reem";
        Testers[1] = "Madina";
        Testers[2] = "Osman";

        System.out.println(Testers[0]);
        System.out.println(Testers[1]);
        System.out.println(Testers[2]);

        System.out.println(Testers.length);

        System.out.println("==========================================");

        String[] students = new String[10];

    }
}
