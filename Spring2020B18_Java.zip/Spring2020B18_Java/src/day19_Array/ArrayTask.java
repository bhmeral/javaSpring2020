package day19_Array;

import java.util.Scanner;

public class ArrayTask {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        String[] days = {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};

        System.out.println("Enter the day index");
        int day = input.nextInt();


        System.out.println("Today is: " + days[day]);









    }
}
