package day20_ArrayContuniue;

public class Max_Min{
    public static void main(String[] args) {
        int[] arr = {2,3,4,5,6,7,8,9};
        int lastIndex = arr.length-1;
        int max = arr[0];
        int min = arr[0];

        for (int i=0; i<=lastIndex; i++){
            if (arr[i]>max){
                max = arr[i];

            }


        System.out.println(max);

            if (arr[i]<min){
                min =arr[i];
            }
    }



    }
}
