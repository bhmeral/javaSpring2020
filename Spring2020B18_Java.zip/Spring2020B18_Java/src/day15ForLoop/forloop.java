package day15ForLoop;

public class forloop {
    public static void main(String[] args) {


            for(int i=0; i < 5 ; i++){
                System.out.println("hello world");
            }
    }
}
