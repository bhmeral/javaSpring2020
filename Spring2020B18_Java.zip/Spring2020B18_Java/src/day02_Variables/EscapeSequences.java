package day02_Variables;

public class EscapeSequences {
    public static void main(String[] args) {
        System.out.println("\tBaha");
        System.out.println("Baha");  // \t means paragraph space


        System.out.println("Cybertek \nShcool");
        System.out.println("Cybertek school");
        System.out.println("My\nname\nis\nbaha");
        // \n means break the line starts with new line

        // print: My favorite TV show is Game of Thrones
        System.out.println("My favorive TV show is \"Game of Thrones\"");
        // \" means double quote, prints double quote to the console


        System.out.println("\\");
        // \\ prints \ on the console
        System.out.println("/");

        System.out.println("My favorite book is 'JAVA'");

    }



}
