package day02_Variables;

public class NewEmployee {
    public static void main(String[] args) { // this is main method
        System.out.println("BABA"); // prints to the console
        System.out.println("BAHA");
        System.out.println("999536");
        System.out.println("PROGRAMMER");
        System.out.println("$150000");


    }
    /* t
   ttt
   t
   t
   t
   t
   t
     */




}
