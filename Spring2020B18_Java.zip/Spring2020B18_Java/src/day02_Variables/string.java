package day02_Variables;

public class string {
    public static void main(String[] args) {

        String NO1 = "Sweet Potato";
        String NO2 = "Red Potato";
        String NO3 = "French Fries";
        String NO4 = "Apple Slices";

        System.out.println(NO3 + " " + NO4);
        System.out.println(NO1);


        System.out.println("===========================================================");



        String myname= "BAHA";
        String mysurname= "MERAL";
        long ID=389070340;

        System.out.println("Name: " +myname );
        System.out.println("Surname: "+mysurname);
        System.out.println("ID: "+ ID);








    }
}
