package day02_Variables;

public class print_VS_println {
    public static void main(String[] args) {
     /*
        System.out.println("hello");
        System.out.println("hello");
       */

       System.out.print("hello");
        System.out.print("hello");
        System.out.println("hello");

        System.out.println("hello"); // new line

    }

}
