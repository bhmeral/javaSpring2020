package day02_Variables;

public class TellMeAboutYourself {
    public static void main(String[] args) {
        System.out.println("BAHA");
        System.out.println("CALIFORNIA");
        System.out.println("PROGRAMMING");
        System.out.println("PHYSICIST");


    }



}
