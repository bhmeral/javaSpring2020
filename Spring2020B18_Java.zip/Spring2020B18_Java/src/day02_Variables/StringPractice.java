package day02_Variables;

public class StringPractice {
    public static void main(String[] args) {




        String companyName = "KAMİL BAHA";
        String employeeName = "Baha MERAL";
        int  salary =  150000;
        String jobTitle = " Kamil Müdürü";
        byte employeID = 13;
        System.out.println("Employee Name:"+ employeeName);
        System.out.println("Company Name :"+ companyName);
        System.out.println("Salary:" + salary);
        System.out.println("Job Title :" + jobTitle);
        System.out.println("Employee ID :" + employeID);





        System.out.println("Employee Name" + employeeName + "\nCompany Name:" + companyName +  "\nEmployee ID:" + employeID+"\nJob Title:" + jobTitle + "\nSalary:" + salary);







    }
}
