package day02_Variables;

public class HelloCybertek {
    public static void main(String[] args) {
        System.out.println("Hello Cybertek");






    }
}
