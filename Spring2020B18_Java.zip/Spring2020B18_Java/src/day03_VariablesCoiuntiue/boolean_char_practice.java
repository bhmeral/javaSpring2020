package day03_VariablesCoiuntiue;

public class boolean_char_practice {
    public static void main(String[] args) {

         int a ='a' + 'b';
        //      97 + 98  ==> 195 > 127
        System.out.println(a);

        boolean r1 = 'a' == 97;
        //           97==97 ==> true
        System.out.println(r1);


    //        System.out.println("a" == 'a');




























    }
}
