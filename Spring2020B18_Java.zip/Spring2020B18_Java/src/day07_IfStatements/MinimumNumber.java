package day07_IfStatements;

public class MinimumNumber {
    public static void main(String[] args) {

        double a = 100;
        double b = 50;
        double c = 59;

        if (a<b && a<c){
            System.out.println( a + " is minimum number.");

        }
        if (b<a && b<c){
            System.out.println( b + " is minimum number.");
        }

        if (c<a && c<b){
            System.out.println( c + " is minimum number.");
        }










    }

}
