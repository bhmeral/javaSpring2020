package day22_ArrayLoop;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Multi_DArrays {
    public static void main(String[] args) {
        int [][] arr2D = { {1,2,3} , {4,5,6} };


        System.out.println(Arrays.toString(arr2D[1]));

    }
}
