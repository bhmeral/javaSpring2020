package day17_WhileLoops;

public class WhileLoopPractice {
    public static void main(String[] args) {

        /*


        for (int i=0; i<100; i++){
            System.out.print("*");
        }
        System.out.println("===============================================");
        */
  /*


        int i = 1;
        while(i<101){
            System.out.print("*");
            i++;
        }
         */
            int number = 0 ;
            System.out.println("********");
            while(number<3){
            System.out.println("*      *");
            number++;
            System.out.println("********");
        }
    }
}
