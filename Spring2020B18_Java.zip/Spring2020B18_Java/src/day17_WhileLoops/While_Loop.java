package day17_WhileLoops;

import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

public class While_Loop {
    public static void main(String[] args) {
             /*
            while(10>9){
            System.out.println("Hello World");
            }
            */

            for (int i =0; i<=5 ;  i++){
                System.out.println(i);
            }
        System.out.println("====================================================");
            int i = 0;
            while(i<=5){
                System.out.println(i);
                i++;
            }

    }
}
