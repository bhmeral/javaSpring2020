package day08_IfStatment;

public class MultiBrancIf {
    public static void main(String[] args) {

        int number = 0;

        if (number>0){
            System.out.println(number + " is positive.");
        } else if(number<0){
            System.out.println(number + " is negative.");
        }else{
            System.out.println(" The number is 0");
        }


















    }
}
